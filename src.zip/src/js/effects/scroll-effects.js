document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  // ── parallax ────────────────────────────────────────────────────────────────
  // data-effect="parallax"
  // data-speed="0.2"          velocidade (default 0.2)
  // data-direction="up"       "up" sobe | "down" desce | "left" esquerda | "right" direita (default "up")
  // data-origin="global"      "global" usa scrollY bruto | "section" relativo ao centro da seção (default "section")

  (function initParallax() {
    const els = document.querySelectorAll('[data-effect~="parallax"]');
    if (!els.length) return;

    function tick() {
      els.forEach(el => {
        const speed     = parseFloat(el.dataset.speed)     || 0.2;
        const dir       = el.dataset.direction             || 'up';
        const origin    = el.dataset.origin                || 'section';

        let delta = 0;

        if (origin === 'global') {
          delta = window.scrollY * speed;
        } else {
          const parent = el.closest('[data-parallax-section]') || el.parentElement;
          const rect   = parent.getBoundingClientRect();
          const inView = rect.bottom > 0 && rect.top < window.innerHeight;
          if (!inView) return;
          delta = ((window.innerHeight / 2) - (rect.top + rect.height / 2)) * speed;
        }

        const sign = (dir === 'down' || dir === 'right') ? -1 : 1;
        const axis = (dir === 'left' || dir === 'right') ? 'X' : 'Y';
        el.style.transform = `translate${axis}(${delta * sign}px)`;
      });
      requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  })();


  // ── fade-scroll ─────────────────────────────────────────────────────────────
  // data-effect="fade-scroll"
  // data-fade-distance="600"   px de scroll para chegar em opacity 0 (default 600)
  // data-blur="3"              px de blur no máximo (default 0)

  (function initFadeScroll() {
    const els = document.querySelectorAll('[data-effect~="fade-scroll"]');
    if (!els.length) return;

    function tick() {
      els.forEach(el => {
        const maxScroll = parseFloat(el.dataset.fadeDistance) || 600;
        const blur      = parseFloat(el.dataset.blur)         || 0;
        const opacity   = Math.max(0, Math.min(1, 1 - window.scrollY / maxScroll));
        el.style.opacity = opacity;
        if (blur) el.style.filter = `blur(${(1 - opacity) * blur}px)`;
      });
      requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  })();


  // ── fade-viewport ────────────────────────────────────────────────────────────
  // data-effect="fade-viewport"
  // data-fade-zone="35"   % da viewport que serve de zona de fade (default 35)
  // Funciona por linha visual — textos longos têm cada linha com opacidade própria

  (function initFadeViewport() {
    const els = document.querySelectorAll('[data-effect~="fade-viewport"]');
    if (!els.length) return;

    els.forEach(el => {
      el.style.webkitMaskRepeat = 'no-repeat';
      el.style.maskRepeat = 'no-repeat';
    });

    function getVisualLines(el) {
      if (el.children.length === 0 && el.textContent.trim()) {
        return getTextLines(el);
      }
      const children = Array.from(el.children);
      if (children.length) return children.map(c => c.getBoundingClientRect());
      return [el.getBoundingClientRect()];
    }

    function getTextLines(el) {
      const textNode = el.firstChild;
      if (!textNode || textNode.nodeType !== Node.TEXT_NODE) return getTextLinesFromChildren(el);
      const range = document.createRange();
      const lines  = [];
      const text   = textNode.textContent;
      let lastTop  = null;
      let lineStart = 0;

      for (let i = 0; i <= text.length; i++) {
        range.setStart(textNode, lineStart);
        range.setEnd(textNode, Math.min(i, text.length));
        const rect = range.getBoundingClientRect();
        if (rect.top !== lastTop && lastTop !== null) {
          range.setStart(textNode, lineStart);
          range.setEnd(textNode, i - 1);
          lines.push(range.getBoundingClientRect());
          lineStart = i - 1;
        }
        lastTop = rect.top;
      }
      if (lineStart < text.length) {
        range.setStart(textNode, lineStart);
        range.setEnd(textNode, text.length);
        lines.push(range.getBoundingClientRect());
      }
      return lines.filter(r => r.width > 0 && r.height > 0);
    }

    function getTextLinesFromChildren(el) {
      const range = document.createRange();
      range.selectNodeContents(el);
      const rects   = Array.from(range.getClientRects());
      const lineMap = new Map();
      rects.forEach(r => {
        const key = Math.round(r.top);
        if (!lineMap.has(key)) {
          lineMap.set(key, r);
        } else {
          const e = lineMap.get(key);
          lineMap.set(key, {
            top: e.top, bottom: Math.max(e.bottom, r.bottom),
            left: Math.min(e.left, r.left), right: Math.max(e.right, r.right),
            height: e.height,
            width: Math.max(e.right, r.right) - Math.min(e.left, r.left),
          });
        }
      });
      return Array.from(lineMap.values()).filter(r => r.width > 0 && r.height > 0);
    }

    function lineOpacity(lineRect, vh, fadeZone) {
      const mid = lineRect.top + lineRect.height / 2;
      if (mid < vh - fadeZone) return 1;
      if (mid > vh) return 0;
      return Math.min(1, Math.max(0, (vh - mid) / fadeZone));
    }

    function applyFade(el, fadeZone, blur) {
      const lines  = getVisualLines(el);
      if (!lines.length) return;
      const vh     = window.innerHeight;
      const elRect = el.getBoundingClientRect();

      if (lines.length === 1) {
        const op = lineOpacity(lines[0], vh, fadeZone);
        el.style.opacity = op;
        el.style.webkitMaskImage = '';
        el.style.maskImage = '';
        el.style.filter = blur ? `blur(${((1 - op) * blur).toFixed(2)}px)` : '';
        return;
      }

      const elH    = elRect.height || 1;
      const sorted = [...lines].sort((a, b) => a.top - b.top);
      const stops  = [];

      sorted.forEach(line => {
        const op  = lineOpacity(line, vh, fadeZone);
        const s   = Math.max(0, ((line.top    - elRect.top) / elH) * 100);
        const e   = Math.min(100, ((line.bottom - elRect.top) / elH) * 100);
        stops.push(`rgba(0,0,0,${op.toFixed(3)}) ${s.toFixed(1)}%`);
        stops.push(`rgba(0,0,0,${op.toFixed(3)}) ${e.toFixed(1)}%`);
      });

      const gradient = `linear-gradient(to bottom, ${stops.join(', ')})`;
      el.style.webkitMaskImage = gradient;
      el.style.maskImage = gradient;
      el.style.opacity = '';

      // blur global baseado na opacidade do centro do elemento
      if (blur) {
        const elOp = lineOpacity(elRect, vh, fadeZone);
        el.style.filter = `blur(${((1 - elOp) * blur).toFixed(2)}px)`;
      } else {
        el.style.filter = '';
      }
    }

    function tick() {
      els.forEach(el => {
        const zone = parseFloat(el.dataset.fadeZone) || window.innerHeight * 0.35;
        const blur = parseFloat(el.dataset.blur)     || 0;
        applyFade(el, zone, blur);
      });
      requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  })();

});