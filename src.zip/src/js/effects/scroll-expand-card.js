const data = [
  { img: 'https://picsum.photos/id/1015/1200/800', title: 'IGGO' },
  { img: 'https://picsum.photos/id/1016/1200/800', title: 'Consultoria' },
  { img: 'https://picsum.photos/id/1018/1200/800', title: 'Tecnologia' },
  { img: 'https://picsum.photos/id/1020/1200/800', title: 'Inovação' },
  { img: 'https://picsum.photos/id/1024/1200/800', title: 'Marketing' }
]

const slidesEl = document.getElementById('slides')

const imgs = []
const texts = []

data.forEach((s, i) => {
  const img = new Image()
  img.src = s.img
  img.className = 'slide' + (i === 0 ? ' active' : '')
  img.decoding = 'async'
  slidesEl.appendChild(img)
  imgs.push(img)

  const t = document.createElement('div')
  t.className = 'text' + (i === 0 ? ' active' : '')
  t.textContent = s.title
  slidesEl.appendChild(t)
  texts.push(t)
})

// pré-decode
Promise.all(imgs.map(img => img.decode?.().catch(()=>{})))

let active = 0

function setSlide(i) {
  if (i === active) return
  imgs[active].classList.remove('active')
  texts[active].classList.remove('active')

  imgs[i].classList.add('active')
  texts[i].classList.add('active')

  active = i
}

const section = document.getElementById('section')
let start = 0
let end = 0

function calc() {
  const rect = section.getBoundingClientRect()
  start = window.scrollY + rect.top
  end = start + section.offsetHeight - window.innerHeight
}

calc()
window.addEventListener('resize', calc)

let raf = null

function tick() {
  raf = null

  const p = Math.max(0, Math.min(1,
    (window.scrollY - start) / (end - start)
  ))

  const scaleX = 0.7 + (1 - 0.7) * p
  const scaleY = 0.6 + (1 - 0.6) * p

  document.getElementById('sticky').style.transform =
    `scale(${scaleX}, ${scaleY})`

  const sc = 1.14 + (1 - 1.14) * p
  imgs[active].style.transform = `scale(${sc})`

  const next = Math.min(data.length - 1, Math.floor(p * data.length))
  setSlide(next)
}

function onScroll() {
  if (!raf) raf = requestAnimationFrame(tick)
}

window.addEventListener('scroll', onScroll, { passive: true })
requestAnimationFrame(tick)