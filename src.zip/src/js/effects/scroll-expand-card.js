(function () {
  'use strict';

  const INITIAL_W_VW = 0.68;
  const INITIAL_H_VH = 0.62;
  const IMG_INITIAL_SCALE = 1.18;
  const IMG_FINAL_SCALE   = 1.0;
  const SMOOTH = 0.08;

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function lerp(a, b, t)  { return a + (b - a) * t; }
  function easeInOut(t)   { return t < 0.5 ? 2*t*t : -1 + (4 - 2*t) * t; }

  function buildCard(section, slides) {
    const imgLayer = document.createElement('div');
    imgLayer.className = 'ec-card-imgs';
    imgLayer.style.overflow = 'hidden';

    slides.forEach((s, i) => {
      const img = document.createElement('img');
      img.src = s.img;
      img.alt = s.title || '';
      img.className = 'ec-img' + (i === 0 ? ' active' : '');
      imgLayer.appendChild(img);
    });

    const flash = document.createElement('div');
    flash.className = 'ec-flash';
    imgLayer.appendChild(flash);

    const bar = document.createElement('div');
    bar.className = 'ec-bar';
    const barFill = document.createElement('div');
    barFill.className = 'ec-bar-fill';
    bar.appendChild(barFill);
    imgLayer.appendChild(bar);

    const dots = document.createElement('div');
    dots.className = 'ec-dots';
    slides.forEach((_, i) => {
      const d = document.createElement('span');
      d.className = 'ec-dot' + (i === 0 ? ' active' : '');
      dots.appendChild(d);
    });
    imgLayer.appendChild(dots);

    const textLayer = document.createElement('div');
    textLayer.className = 'ec-card-text';

    slides.forEach((s, i) => {
      const block = document.createElement('div');
      block.className = 'ec-text' + (i === 0 ? ' active' : '');
      if (s.title == 'IGGO.') {
        block.innerHTML = `<img src="public/logos/png/logo.png" alt="" class="logo">`;
      } else {
        block.innerHTML = `<h2 class="ec-title" style="mix-blend-mode: difference;">${s.title || ''}</h2>`;
      }
      if (i !== 0) block.style.display = 'none';
      textLayer.appendChild(block);
    });

    imgLayer.appendChild(textLayer);
    section.appendChild(imgLayer);

    return { imgLayer, textLayer, dots, barFill, flash };
  }

  function initSection(section) {
    const cardEl = section.querySelector('.expand-card');
    let slides = [];
    try { slides = JSON.parse(cardEl?.dataset.slides || '[]'); } catch(e) { return; }
    if (!slides.length) return;
    cardEl?.remove();

    const n = slides.length;
    const scrollHeight = parseFloat(section.dataset.scrollHeight) || n * 180;
    section.style.height = `${scrollHeight}vh`;

    const placeholder = document.createElement('div');
    placeholder.className = 'ec-placeholder';
    section.insertBefore(placeholder, section.firstChild);

    const { imgLayer, textLayer, dots, barFill, flash } = buildCard(section, slides);

    let activeSlide = -1;
    let smoothProgress = 0;
    let transitioning = false;

    function setSlide(idx) {
      if (idx === activeSlide) return;

      const prevIdx = activeSlide;
      activeSlide = idx;

      const imgs = imgLayer.querySelectorAll('.ec-img');
      const texts = textLayer.querySelectorAll('.ec-text');

      transitioning = true;
      flash.style.transition = 'opacity 0.18s ease';
      flash.style.opacity = '1';

      setTimeout(() => {
        if (prevIdx >= 0) {
          imgs[prevIdx].classList.remove('active');
          texts[prevIdx].style.display = 'none';
          texts[prevIdx].classList.remove('active');
        }
        imgs[idx].classList.add('active');
        texts[idx].style.display = 'flex';
        texts[idx].classList.add('active');

        dots.querySelectorAll('.ec-dot').forEach((el, i) => {
          el.classList.toggle('active', i === idx);
        });

        flash.style.opacity = '0';
        setTimeout(() => { transitioning = false; }, 200);
      }, 180);
    }

    function update() {
      const vh = window.innerHeight;
      const vw = window.innerWidth;

      const initW = vw * INITIAL_W_VW;
      const initH = vh * INITIAL_H_VH;

      placeholder.style.width = `${initW}px`;
      placeholder.style.height = `${initH}px`;

      const sectionTop = section.getBoundingClientRect().top + window.scrollY;
      const placeholderOffsetTop = placeholder.offsetTop;
      const stickAt = sectionTop + placeholderOffsetTop + initH / 2 - vh / 2;
      const endAt = sectionTop + section.offsetHeight - vh;

      const scrollY = window.scrollY;
      const rawProgress = clamp((scrollY - stickAt) / (endAt - stickAt), 0, 1);

      smoothProgress = lerp(smoothProgress, rawProgress, SMOOTH);
      const progress = smoothProgress;
      const eased = easeInOut(progress);

      const w = lerp(initW, vw, eased);
      const h = lerp(initH, vh, eased);

      if (scrollY < stickAt) {
        imgLayer.style.position = 'absolute';
        imgLayer.style.width = `${initW}px`;
        imgLayer.style.height = `${initH}px`;
        imgLayer.style.top = `${placeholder.offsetTop}px`;
        imgLayer.style.left = `${(vw - initW) / 2 - 8}px`;
        imgLayer.style.bottom = '';
      } else if (rawProgress < 1) {
        imgLayer.style.position = 'fixed';
        imgLayer.style.width = `${w}px`;
        imgLayer.style.height = `${h}px`;
        imgLayer.style.top = `${(vh - h) / 2}px`;
        imgLayer.style.left = `${(vw - w) / 2 - 8}px`;
        imgLayer.style.bottom = '';
      } else {
        imgLayer.style.position = 'absolute';
        imgLayer.style.bottom = '0';
        imgLayer.style.top = 'auto';
        imgLayer.style.height = '100vh';
      }

      const slideIdx = clamp(Math.floor(progress * n), 0, n - 1);
      setSlide(slideIdx);

      const sliceProgress = (progress - slideIdx / n) / (1 / n);
      barFill.style.width = `${clamp(sliceProgress * 100, 0, 100)}%`;

      const imgScale = lerp(IMG_INITIAL_SCALE, IMG_FINAL_SCALE, easeInOut(progress));
      imgLayer.querySelectorAll('.ec-img').forEach(img => {
        img.style.transform = `scale(${imgScale})`;
      });
    }

    function tick() { update(); requestAnimationFrame(tick); }
    requestAnimationFrame(tick);
  }

  function init() {
    document.querySelectorAll('.expand-card-section').forEach(initSection);
  }

  document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', init)
    : init();
})();
