import { Camera, Mesh, Plane, Program, Renderer, Texture, Transform } from 'ogl';

const isMobile = window.matchMedia('(hover: none) and (pointer: coarse)').matches || navigator.maxTouchPoints > 0;

function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

function lerp(p1, p2, t) {
  return p1 + (p2 - p1) * t;
}

function createTextTexture(gl, text, font = 'bold 30px monospace', color = 'white') {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.font = font;
  const metrics = ctx.measureText(text);
  const textWidth = Math.ceil(metrics.width);
  const textHeight = Math.ceil(parseInt(font, 10) * 1.2);
  canvas.width = textWidth + 20;
  canvas.height = textHeight + 20;
  ctx.font = font;
  ctx.fillStyle = color;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillText(text, canvas.width / 2, canvas.height / 2);
  const texture = new Texture(gl, { generateMipmaps: false });
  texture.image = canvas;
  return { texture, width: canvas.width, height: canvas.height };
}

class Title {
  constructor({ gl, plane, renderer, text, textColor = '#ffffff', font = 'bold 30px Figtree' }) {
    this.gl = gl;
    this.plane = plane;
    this.renderer = renderer;
    this.text = text;
    this.textColor = textColor;
    this.font = font;
    this.createMesh();
  }

  createMesh() {
    const { texture, width, height } = createTextTexture(this.gl, this.text, this.font, this.textColor);
    const geometry = new Plane(this.gl);
    const program = new Program(this.gl, {
      vertex: `
        attribute vec3 position;
        attribute vec2 uv;
        uniform mat4 modelViewMatrix;
        uniform mat4 projectionMatrix;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragment: `
        precision highp float;
        uniform sampler2D tMap;
        varying vec2 vUv;
        void main() {
          vec4 color = texture2D(tMap, vUv);
          if (color.a < 0.1) discard;
          gl_FragColor = color;
        }
      `,
      uniforms: { tMap: { value: texture } },
      transparent: true
    });
    this.mesh = new Mesh(this.gl, { geometry, program });
    const aspect = width / height;
    const textHeight = this.plane.scale.y * 0.15;
    const textWidth = textHeight * aspect;
    this.mesh.scale.set(textWidth, textHeight, 1);
    this.mesh.position.y = -this.plane.scale.y * 0.5 - textHeight * 0.5 - 0.05;
    this.mesh.setParent(this.plane);
  }
}

class Media {
  constructor({ geometry, gl, image, index, length, renderer, scene, screen, text, viewport, bend, textColor, borderRadius = 0, font }) {
    this.extra = 0;
    this.geometry = geometry;
    this.gl = gl;
    this.image = image;
    this.index = index;
    this.length = length;
    this.renderer = renderer;
    this.scene = scene;
    this.screen = screen;
    this.text = text;
    this.viewport = viewport;
    this.bend = bend;
    this.textColor = textColor;
    this.borderRadius = borderRadius;
    this.font = font;
    this.createShader();
    this.createMesh();
    this.createTitle();
    this.onResize();
  }

  createShader() {
    const texture = new Texture(this.gl, { generateMipmaps: true });
    this.program = new Program(this.gl, {
      depthTest: false,
      depthWrite: false,
      vertex: `
        precision highp float;
        attribute vec3 position;
        attribute vec2 uv;
        uniform mat4 modelViewMatrix;
        uniform mat4 projectionMatrix;
        uniform float uTime;
        uniform float uSpeed;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec3 p = position;
          p.z = (sin(p.x * 4.0 + uTime) * 1.5 + cos(p.y * 2.0 + uTime) * 1.5) * (0.1 + uSpeed * 0.5);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }
      `,
      fragment: `
        precision highp float;
        uniform vec2 uImageSizes;
        uniform vec2 uPlaneSizes;
        uniform sampler2D tMap;
        uniform float uBorderRadius;
        varying vec2 vUv;

        float roundedBoxSDF(vec2 p, vec2 b, float r) {
          vec2 d = abs(p) - b;
          return length(max(d, vec2(0.0))) + min(max(d.x, d.y), 0.0) - r;
        }

        void main() {
          vec2 ratio = vec2(
            min((uPlaneSizes.x / uPlaneSizes.y) / (uImageSizes.x / uImageSizes.y), 1.0),
            min((uPlaneSizes.y / uPlaneSizes.x) / (uImageSizes.y / uImageSizes.x), 1.0)
          );
          vec2 uv = vec2(
            vUv.x * ratio.x + (1.0 - ratio.x) * 0.5,
            vUv.y * ratio.y + (1.0 - ratio.y) * 0.5
          );
          vec4 color = texture2D(tMap, uv);
          float d = roundedBoxSDF(vUv - 0.5, vec2(0.5 - uBorderRadius), uBorderRadius);
          float edgeSmooth = 0.002;
          float alpha = 1.0 - smoothstep(-edgeSmooth, edgeSmooth, d);
          gl_FragColor = vec4(color.rgb, alpha);
        }
      `,
      uniforms: {
        tMap: { value: texture },
        uPlaneSizes: { value: [0, 0] },
        uImageSizes: { value: [0, 0] },
        uSpeed: { value: 0 },
        uTime: { value: 100 * Math.random() },
        uBorderRadius: { value: this.borderRadius }
      },
      transparent: true
    });
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = this.image;
    img.onload = () => {
      texture.image = img;
      this.program.uniforms.uImageSizes.value = [img.naturalWidth, img.naturalHeight];
    };
  }

  createMesh() {
    this.plane = new Mesh(this.gl, { geometry: this.geometry, program: this.program });
    this.plane.setParent(this.scene);
  }

  createTitle() {
    this.title = new Title({
      gl: this.gl,
      plane: this.plane,
      renderer: this.renderer,
      text: this.text,
      textColor: this.textColor,
      font: this.font
    });
  }

  update(scroll, direction, isScrolling) {
    this.plane.position.x = this.x - scroll.current - this.extra;

    const x = this.plane.position.x;
    const H = this.viewport.width / 2;

    if (this.bend === 0) {
      this.plane.position.y = 0;
      this.plane.rotation.z = 0;
    } else {
      const B_abs = Math.abs(this.bend);
      const R = (H * H + B_abs * B_abs) / (2 * B_abs);
      const effectiveX = Math.min(Math.abs(x), H);
      const arc = R - Math.sqrt(R * R - effectiveX * effectiveX);
      if (this.bend > 0) {
        this.plane.position.y = -arc;
        this.plane.rotation.z = -Math.sign(x) * Math.asin(effectiveX / R);
      } else {
        this.plane.position.y = arc;
        this.plane.rotation.z = Math.sign(x) * Math.asin(effectiveX / R);
      }
    }

    this.speed = scroll.current - scroll.last;
    if (isScrolling) this.program.uniforms.uTime.value += 0.04;
    this.program.uniforms.uSpeed.value = this.speed;

    const planeOffset = this.plane.scale.x / 2;
    const viewportOffset = this.viewport.width / 2;
    this.isBefore = this.plane.position.x + planeOffset < -viewportOffset;
    this.isAfter  = this.plane.position.x - planeOffset >  viewportOffset;

    if (direction === 'right' && this.isBefore) {
      this.extra -= this.widthTotal;
      this.isBefore = this.isAfter = false;
    }
    if (direction === 'left' && this.isAfter) {
      this.extra += this.widthTotal;
      this.isBefore = this.isAfter = false;
    }
  }

  onResize({ screen, viewport } = {}) {
    if (screen)   this.screen   = screen;
    if (viewport) this.viewport = viewport;

    this.scale = this.screen.height / 1500;
    this.plane.scale.y = (this.viewport.height * (500 * this.scale)) / this.screen.height;
    this.plane.scale.x = (this.viewport.width  * (400 * this.scale)) / this.screen.width;
    this.plane.program.uniforms.uPlaneSizes.value = [this.plane.scale.x, this.plane.scale.y];

    this.padding    = 2;
    this.width      = this.plane.scale.x + this.padding;
    this.widthTotal = this.width * this.length;
    this.x          = this.width * this.index;
  }
}

class App {
  constructor(container, {
    items,
    bend         = 3,
    textColor    = '#ffffff',
    borderRadius = 0.00,
    font         = 'bold 30px Figtree',
    scrollSpeed  = .08,
    scrollEase   = 0.05
  } = {}) {
    this.container   = container;
    this.scrollSpeed = scrollSpeed;
    this.scroll      = { ease: scrollEase, current: 0, target: 0, last: 0 };
    this.isVisible   = true;
    this.isScrolling = false;
    this._scrollTimeout = null;
    this.onCheckDebounce = debounce(this.onCheck.bind(this), 200);

    this.createRenderer();
    this.createCamera();
    this.createScene();
    this.onResize();
    this.createGeometry();
    this.createMedias(items, bend, textColor, borderRadius, font);
    this.addEventListeners();
    this.observeVisibility();
    this.update();
  }

  createRenderer() {
    const dpr = isMobile
      ? Math.min(window.devicePixelRatio || 1, 1.5)
      : Math.min(window.devicePixelRatio || 1, 2);

    this.renderer = new Renderer({ alpha: true, antialias: !isMobile, dpr });
    this.gl = this.renderer.gl;
    this.gl.clearColor(0, 0, 0, 0);
    this.container.appendChild(this.gl.canvas);
  }

  createCamera() {
    this.camera = new Camera(this.gl);
    this.camera.fov = 85;
    this.camera.position.z = 20;
  }

  createScene() {
    this.scene = new Transform();
  }

  createGeometry() {
    const w = isMobile ? 40 : 100;
    const h = isMobile ? 20 : 50;
    this.planeGeometry = new Plane(this.gl, { widthSegments: w, heightSegments: h });
  }

  createMedias(items, bend = 1, textColor, borderRadius, font) {
    const defaultItems = [
      { image: 'img/Brands/Yatsar/fcfd13a3db44f4140b3afcc032bd4466.jpg',  text: 'Ponte'     },
      { image: 'img/Brands/Bellavivele/bellavivele-card-1.jpg',           text: 'Setup'     },
      { image: 'img/Brands/SaveClip.App_624985612_18071595905410739_383912863494837089_n.jpg', text: 'Cachoeira' },
      { image: 'img/Brands/SaveClip.App_624461653_18105168457774409_8253944625963913622_n.jpg', text: 'Frutas'    },
      { image: 'img/Brands/18 Sem Título_20260426004126.png',             text: 'Frutas'    }
    ];

    const galleryItems = (items && items.length) ? items : defaultItems;
    this.mediasImages  = galleryItems.concat(galleryItems);
    this.medias        = this.mediasImages.map((data, index) =>
      new Media({
        geometry: this.planeGeometry,
        gl: this.gl,
        image: data.image,
        index,
        length: this.mediasImages.length,
        renderer: this.renderer,
        scene: this.scene,
        screen: this.screen,
        text: data.text,
        viewport: this.viewport,
        bend,
        textColor,
        borderRadius,
        font
      })
    );
  }

  observeVisibility() {
    this._obs = new IntersectionObserver(([entry]) => {
      this.isVisible = entry.isIntersecting;
      if (this.isVisible && !this.raf) this.update();
    }, { threshold: 0 });
    this._obs.observe(this.container);
  }

  _markScrolling() {
    this.isScrolling = true;
    clearTimeout(this._scrollTimeout);
    this._scrollTimeout = setTimeout(() => { this.isScrolling = false; }, 150);
  }

  onTouchDown(e) {
    this.isDown = true;
    this.scroll.position = this.scroll.current;
    this.start = e.touches ? e.touches[0].clientX : e.clientX;
  }

  onTouchMove(e) {
    if (!this.isDown) return;
    const x = e.touches ? e.touches[0].clientX : e.clientX;
    const distance = (this.start - x) * (this.scrollSpeed * 0.025);
    this.scroll.target = this.scroll.position + distance;
    this._markScrolling();
  }

  onTouchUp() {
    this.isDown = false;
    this.onCheck();
  }

  onWheel(e) {
    const delta = e.deltaY || e.wheelDelta || e.detail;
    this.scroll.target += (delta > 0 ? this.scrollSpeed : -this.scrollSpeed) * 0.2;
    this._markScrolling();
    this.onCheckDebounce();
  }

  onCheck() {
    if (!this.medias || !this.medias[0]) return;
    const width     = this.medias[0].width;
    const itemIndex = Math.round(Math.abs(this.scroll.target) / width);
    const item      = width * itemIndex;
    this.scroll.target = this.scroll.target < 0 ? -item : item;
  }

  onResize() {
    this.screen = {
      width:  this.container.clientWidth,
      height: this.container.clientHeight
    };
    this.renderer.setSize(this.screen.width, this.screen.height);
    this.camera.perspective({ aspect: this.screen.width / this.screen.height });

    const fov    = (this.camera.fov * Math.PI) / 180;
    const height = 2 * Math.tan(fov / 2) * this.camera.position.z;
    const width  = height * this.camera.aspect;
    this.viewport = { width, height };

    if (this.medias) {
      this.medias.forEach(m => m.onResize({ screen: this.screen, viewport: this.viewport }));
    }
  }

  update() {
    if (!this.isVisible) {
      this.raf = null;
      return;
    }

    this.scroll.current = lerp(this.scroll.current, this.scroll.target, this.scroll.ease);
    const direction = this.scroll.current > this.scroll.last ? 'right' : 'left';
    if (this.medias) this.medias.forEach(m => m.update(this.scroll, direction, this.isScrolling));
    this.renderer.render({ scene: this.scene, camera: this.camera });
    this.scroll.last = this.scroll.current;
    this.raf = requestAnimationFrame(this.update.bind(this));
  }

  addEventListeners() {
    this._onResize    = this.onResize.bind(this);
    this._onWheel     = this.onWheel.bind(this);
    this._onTouchDown = this.onTouchDown.bind(this);
    this._onTouchMove = this.onTouchMove.bind(this);
    this._onTouchUp   = this.onTouchUp.bind(this);

    window.addEventListener('resize',     this._onResize);
    window.addEventListener('wheel',      this._onWheel);
    window.addEventListener('mousewheel', this._onWheel);
    window.addEventListener('mousedown',  this._onTouchDown);
    window.addEventListener('mousemove',  this._onTouchMove);
    window.addEventListener('mouseup',    this._onTouchUp);
    window.addEventListener('touchstart', this._onTouchDown);
    window.addEventListener('touchmove',  this._onTouchMove);
    window.addEventListener('touchend',   this._onTouchUp);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this._obs.disconnect();
    window.removeEventListener('resize',     this._onResize);
    window.removeEventListener('wheel',      this._onWheel);
    window.removeEventListener('mousewheel', this._onWheel);
    window.removeEventListener('mousedown',  this._onTouchDown);
    window.removeEventListener('mousemove',  this._onTouchMove);
    window.removeEventListener('mouseup',    this._onTouchUp);
    window.removeEventListener('touchstart', this._onTouchDown);
    window.removeEventListener('touchmove',  this._onTouchMove);
    window.removeEventListener('touchend',   this._onTouchUp);
    if (this.gl.canvas.parentNode) this.gl.canvas.parentNode.removeChild(this.gl.canvas);

    // libera o contexto WebGL de fato,  sem isso, o navegador pode demorar
    // pra coletar contextos antigos e, depois de algumas idas e voltas pra
    // home, bate no limite de contextos WebGL simultâneos (geralmente
    // 8-16) e a galeria simplesmente para de aparecer, sem erro nenhum.
    const loseCtx = this.gl.getExtension('WEBGL_lose_context');
    if (loseCtx) loseCtx.loseContext();
  }
}

/* ---------- REINIT AO VOLTAR PRA HOME ----------
   Antes, `container` era pego uma única vez no carregamento do script,
   e o App WebGL criado sobre ele nunca era destruído. Quando o
   page-router troca de página e volta pra home, o #gallery-container é
   recriado do zero (snapshot),  o App antigo continuava rodando seu
   loop de render e seus listeners de wheel/touch presos no <canvas>
   órfão (que ninguém via mais), e o novo #gallery-container nunca
   ganhava sua própria galeria. A classe App já tinha um destroy()
   pronto,  só faltava chamar. */
let currentApp = null;
let generation = 0;

function initGallery(myGen) {
  if (myGen !== generation) return; // um pagechange mais novo já assumiu,  descarta esta tentativa

  const container = document.getElementById('gallery-container');
  if (!container) return; // página atual não tem galeria

  if (container.clientWidth === 0 || container.clientHeight === 0) {
    requestAnimationFrame(() => initGallery(myGen));
    return;
  }

  if (currentApp) {
    currentApp.destroy();
    currentApp = null;
  }

  // limpa qualquer resto (ex: o <canvas> antigo que já veio dentro do
  // #gallery-container quando o snapshot da home foi restaurado,  ele
  // fica ocupando espaço e o overflow:hidden do container acaba
  // escondendo o canvas novo atrás dele)
  container.innerHTML = '';

  currentApp = new App(container, {
    bend:         0,
    textColor:    '#ffffff',
    borderRadius: 0.00,
    scrollSpeed:  2,
    scrollEase:   0.05
  });
}

requestAnimationFrame(() => initGallery(generation));

document.addEventListener('pagechange', () => {
  generation++; // invalida qualquer initGallery ainda esperando de uma navegação anterior
  if (currentApp) {
    currentApp.destroy();
    currentApp = null;
  }
  requestAnimationFrame(() => initGallery(generation));
});