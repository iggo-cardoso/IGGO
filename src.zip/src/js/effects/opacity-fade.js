// opacity-fade.js
// Efeito: elementos com data-effect="opacity-fade" recebem um degradê de opacidade
// conforme a posição na viewport — linhas mais próximas da borda inferior
// ficam mais transparentes. Se for texto em múltiplas linhas, cada linha
// é tratada individualmente de forma gradual.

(function () {
  'use strict';

  // ── Utilitários ────────────────────────────────────────────────────────────

  /**
   * Dado um elemento, retorna um array de "linhas visuais" com seus bounding rects.
   * Para texto: usa Range para detectar quebras reais de linha.
   * Para outros elementos: usa os filhos diretos ou o próprio elemento.
   */
  function getVisualLines(el) {
    const text = el.textContent || '';
    const isTextNode = el.children.length === 0 && text.trim().length > 0;

    // ── Texto puro: quebra por Range ─────────────────────────────────────────
    if (isTextNode) {
      return getTextLines(el);
    }

    // ── Elemento com filhos: cada filho é uma "linha" ────────────────────────
    const children = Array.from(el.children);
    if (children.length > 0) {
      return children.map(child => child.getBoundingClientRect());
    }

    // ── Fallback: o próprio elemento ─────────────────────────────────────────
    return [el.getBoundingClientRect()];
  }

  /**
   * Divide o texto de um elemento em linhas visuais usando a API Range.
   * Funciona independente de font-size, line-height ou wrap.
   */
  function getTextLines(el) {
    const range = document.createRange();
    const textNode = el.firstChild;

    if (!textNode || textNode.nodeType !== Node.TEXT_NODE) {
      // Pode ter spans internos — itera pelos childNodes de texto
      return getTextLinesFromChildren(el);
    }

    const lines = [];
    const text = textNode.textContent;
    let lastTop = null;
    let lineStart = 0;

    for (let i = 0; i <= text.length; i++) {
      range.setStart(textNode, lineStart);
      range.setEnd(textNode, Math.min(i, text.length));
      const rect = range.getBoundingClientRect();

      if (rect.top !== lastTop && lastTop !== null) {
        // Nova linha detectada — salva a linha anterior
        range.setStart(textNode, lineStart);
        range.setEnd(textNode, i - 1);
        lines.push(range.getBoundingClientRect());
        lineStart = i - 1;
      }

      lastTop = rect.top;
    }

    // Última linha
    if (lineStart < text.length) {
      range.setStart(textNode, lineStart);
      range.setEnd(textNode, text.length);
      lines.push(range.getBoundingClientRect());
    }

    return lines.filter(r => r.width > 0 && r.height > 0);
  }

  /**
   * Versão para elementos com filhos mistos (spans, strong, etc.)
   */
  function getTextLinesFromChildren(el) {
    const range = document.createRange();
    range.selectNodeContents(el);
    const rects = Array.from(range.getClientRects());

    // Agrupa rects por top (linha visual)
    const lineMap = new Map();
    rects.forEach(r => {
      const key = Math.round(r.top);
      if (!lineMap.has(key)) lineMap.set(key, r);
      else {
        // Expande o rect da linha para cobrir toda a largura
        const existing = lineMap.get(key);
        lineMap.set(key, {
          top: existing.top,
          bottom: Math.max(existing.bottom, r.bottom),
          left: Math.min(existing.left, r.left),
          right: Math.max(existing.right, r.right),
          height: existing.height,
          width: Math.max(existing.right, r.right) - Math.min(existing.left, r.left),
        });
      }
    });

    return Array.from(lineMap.values()).filter(r => r.width > 0 && r.height > 0);
  }

  // ── Core do efeito ──────────────────────────────────────────────────────────

  /**
   * Calcula a opacidade de uma linha com base na posição na viewport.
   *
   * Zona de fade: da borda inferior até `fadeZone`px acima dela.
   * Linhas no topo da viewport: opacity 1
   * Linhas na zona de fade: opacity 0→1 gradualmente
   */
  function calcLineOpacity(lineRect, viewportHeight, fadeZone) {
    const lineMid = lineRect.top + lineRect.height / 2;

    // Acima da zona de fade: totalmente visível
    if (lineMid < viewportHeight - fadeZone) return 1;

    // Abaixo da borda: invisível
    if (lineMid > viewportHeight) return 0;

    // Dentro da zona: interpolação linear
    const progress = (viewportHeight - lineMid) / fadeZone;
    return Math.min(1, Math.max(0, progress));
  }

  /**
   * Aplica o efeito em um elemento usando clip-path + mask gradiente por linha.
   * Estratégia: cria um SVG linearGradient dinâmico como máscara CSS.
   *
   * Para texto em múltiplas linhas, cada linha recebe sua própria opacidade
   * — o gradiente é reconstruído a cada frame.
   */
  function applyFadeEffect(el, fadeZone) {
    const lines = getVisualLines(el);
    if (lines.length === 0) return;

    const elRect = el.getBoundingClientRect();
    const vh = window.innerHeight;

    if (lines.length === 1) {
      // Elemento de uma linha: opacidade simples
      const op = calcLineOpacity(lines[0], vh, fadeZone);
      el.style.opacity = op;
      el.style.webkitMaskImage = '';
      el.style.maskImage = '';
      return;
    }

    // Múltiplas linhas: constrói um gradiente CSS com stops por linha
    // Cada linha tem sua opacidade, o gradiente vai de cima para baixo
    const elTop = elRect.top;
    const elHeight = elRect.height || 1;

    // Ordena linhas por posição vertical
    const sortedLines = [...lines].sort((a, b) => a.top - b.top);

    // Monta stops do gradiente
    // Cada linha contribui com dois stops: início e fim da linha
    const stops = [];

    sortedLines.forEach((line) => {
      const op = calcLineOpacity(line, vh, fadeZone);

      // Posição relativa ao elemento (0% = topo, 100% = base)
      const startPct = Math.max(0, ((line.top - elTop) / elHeight) * 100);
      const endPct   = Math.min(100, ((line.bottom - elTop) / elHeight) * 100);

      stops.push(`rgba(0,0,0,${op.toFixed(3)}) ${startPct.toFixed(1)}%`);
      stops.push(`rgba(0,0,0,${op.toFixed(3)}) ${endPct.toFixed(1)}%`);
    });

    const gradient = `linear-gradient(to bottom, ${stops.join(', ')})`;
    el.style.webkitMaskImage = gradient;
    el.style.maskImage = gradient;
    el.style.opacity = '';
  }

  // ── Init ────────────────────────────────────────────────────────────────────

  function init() {
    const targets = document.querySelectorAll('[data-effect="opacity-fade"]');
    if (targets.length === 0) return;

    targets.forEach(el => {
      // overflow: visible para não cortar o elemento pai
      el.style.webkitMaskRepeat = 'no-repeat';
      el.style.maskRepeat = 'no-repeat';
    });

    function tick() {
      targets.forEach(el => {
        // Lê data-fade-zone para personalizar por elemento (default: 35% da viewport)
        const fadeZone = parseFloat(el.dataset.fadeZone) || window.innerHeight * 0.35;
        applyFadeEffect(el, fadeZone);
      });
      requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();