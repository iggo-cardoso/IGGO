// elastic-entrance.js
// Entrada "elástica": o elemento vem de uma direção, passa um pouco
// da posição final (overshoot) e volta, parando no lugar certo. Sem
// keyframes manuais de vai-e-vem,  é uma única animação com easing
// "back" (cubic-bezier com overshoot natural).
//
// Uso:
//   <div data-elastic-effect-entrance="up">...</div>
//
// Direções (de onde o elemento vem):
//   up    -> vem de baixo, entra subindo
//   down  -> vem de cima, entra descendo
//   left  -> vem da direita, entra indo pra esquerda
//   right -> vem da esquerda, entra indo pra direita
//
// Opcionais (px / ms):
//   data-elastic-distance="80"   default 80
//   data-elastic-duration="900"  default 900
//   data-elastic-delay="0"       default 0
//
// Dispara uma vez, quando o elemento entra no viewport (não é
// contínuo tipo o parallax/fade-scroll). Refaz o setup em
// 'pagechange' pra funcionar com o page-router (SPA).

(function () {
  const SELECTOR = '[data-elastic-effect-entrance]';
  const EASING   = 'cubic-bezier(.34, 1.56, .64, 1)'; // "back" ease, overshoot embutido

  const OFFSETS = {
    up:    (d) => `translateY(${d}px)`,
    down:  (d) => `translateY(${-d}px)`,
    left:  (d) => `translateX(${d}px)`,
    right: (d) => `translateX(${-d}px)`,
  };

  let observer = null;
  const played = new WeakSet();

  function readParams(el) {
    const dir = el.dataset.elasticEffectEntrance;
    const offsetFn = OFFSETS[dir];
    if (!offsetFn) return null;

    return {
      offsetFn,
      distance: parseFloat(el.dataset.elasticDistance) || 80,
      duration: parseFloat(el.dataset.elasticDuration) || 900,
      delay:    parseFloat(el.dataset.elasticDelay)    || 0,
    };
  }

  function setInitial(el) {
    const p = readParams(el);
    if (!p) return;
    el.style.transform  = p.offsetFn(p.distance);
    el.style.willChange = 'transform';
  }

  function play(el) {
    if (played.has(el)) return;
    played.add(el);

    const p = readParams(el);
    if (!p) return;

    const anim = el.animate(
      [{ transform: p.offsetFn(p.distance) }, { transform: 'translate(0, 0)' }],
      { duration: p.duration, delay: p.delay, easing: EASING, fill: 'forwards' }
    );

    anim.finished
      .then(() => { el.style.transform = ''; el.style.willChange = ''; })
      .catch(() => {});
  }

  function refresh() {
    if (observer) observer.disconnect();

    const els = Array.from(document.querySelectorAll(SELECTOR));
    if (!els.length) return;

    els.forEach((el) => { if (!played.has(el)) setInitial(el); });

    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          play(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });

    els.forEach((el) => { if (!played.has(el)) observer.observe(el); });
  }

  document.addEventListener('pagechange', refresh);
  refresh();
})();
